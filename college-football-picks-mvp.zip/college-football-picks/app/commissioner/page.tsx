import Link from 'next/link';

export default function Commissioner() {
  return <main className="container">
    <h1>Commissioner Dashboard</h1>
    <p className="muted">Manage weeks, games, locked spreads, submissions, ESPN results, scoring, and eliminations.</p>
    <div className="grid grid-3" style={{marginTop:20}}>
      <div className="card"><div className="muted">Players</div><div className="stat">28</div></div>
      <div className="card"><div className="muted">Games This Week</div><div className="stat">15</div></div>
      <div className="card"><div className="muted">Week Status</div><div className="stat" style={{fontSize:20}}>Setup</div></div>
    </div>
    <div className="card" style={{marginTop:16}}>
      <h2>ESPN Result Test</h2>
      <p className="muted">The backend parser is ready to test against an ESPN event ID. Example: 401858461.</p>
      <Link href="/api/espn/401858461"><button>Fetch Example Game</button></Link>
    </div>
  </main>;
}
