import Link from 'next/link';

export default function Home() {
  return <main className="container">
    <div className="card">
      <h1>College Football Picks</h1>
      <p className="muted">Prediction league, automatic scoring, standings, and eliminations.</p>
      <p>This first build is designed around your existing 15-game weekly format and ESPN event IDs.</p>
      <div style={{display:'flex',gap:10,marginTop:20}}>
        <Link href="/dashboard"><button>Player Dashboard</button></Link>
        <Link href="/commissioner"><button className="secondary">Commissioner Dashboard</button></Link>
      </div>
    </div>
  </main>;
}
