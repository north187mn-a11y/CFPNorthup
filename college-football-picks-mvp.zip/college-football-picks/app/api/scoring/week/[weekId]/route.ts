import { NextResponse } from 'next/server';
import { supabaseAdmin } from '@/lib/supabase';
import { scorePick, roundPoints } from '@/lib/scoring';

export async function POST(_: Request, { params }: { params: Promise<{ weekId: string }> }) {
  try {
    const { weekId } = await params;
    const db = supabaseAdmin();
    const { data: picks, error } = await db.from('picks').select('id, player_id, selected_side, games(home_spread, away_spread, winner)').eq('week_id', weekId);
    if (error) throw error;

    const totals = new Map<string, number>();
    for (const pick of picks ?? []) {
      const game = Array.isArray(pick.games) ? pick.games[0] : pick.games;
      if (!game?.winner) continue;
      const points = roundPoints(scorePick(pick.selected_side, game));
      totals.set(pick.player_id, roundPoints((totals.get(pick.player_id) ?? 0) + points));
      await db.from('pick_results').upsert({ pick_id: pick.id, points, correct: points > 0, favorite: (pick.selected_side === 'home' ? game.home_spread : game.away_spread) < 0, spread: pick.selected_side === 'home' ? game.home_spread : game.away_spread });
    }
    for (const [playerId, points] of totals) await db.from('weekly_scores').upsert({ week_id: weekId, player_id: playerId, points });
    return NextResponse.json({ weekId, totals: Object.fromEntries(totals) });
  } catch (error) {
    return NextResponse.json({ error: error instanceof Error ? error.message : 'Unknown error' }, { status: 500 });
  }
}
