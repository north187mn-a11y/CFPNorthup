import { NextResponse } from 'next/server';
import { fetchESPNGame } from '@/lib/espn';
import { supabaseAdmin } from '@/lib/supabase';

export async function POST(_: Request, { params }: { params: Promise<{ gameId: string }> }) {
  try {
    const { gameId } = await params;
    const db = supabaseAdmin();
    const { data: game, error } = await db.from('games').select('*').eq('id', gameId).single();
    if (error || !game) throw error ?? new Error('Game not found');
    if (!game.espn_event_id) throw new Error('Game has no ESPN event ID.');

    const result = await fetchESPNGame(game.espn_event_id);
    const home = result.teams.find(t => t.id === game.home_team_id) ?? result.teams.find(t => t.name === game.home_team);
    const away = result.teams.find(t => t.id === game.away_team_id) ?? result.teams.find(t => t.name === game.away_team);
    if (!home || !away) throw new Error('ESPN teams did not match the league game. No database result was changed.');

    const winner = result.status === 'final'
      ? (result.winnerTeamId === (home.id || home.name) ? 'home' : result.winnerTeamId === (away.id || away.name) ? 'away' : null)
      : null;

    const patch = {
      status: result.status === 'final' ? 'FINAL' : result.status === 'in_progress' ? 'IN_PROGRESS' : result.status === 'scheduled' ? 'SCHEDULED' : game.status,
      home_score: home.score,
      away_score: away.score,
      winner,
      source_url: result.sourceUrl,
      last_synced_at: new Date().toISOString()
    };
    const { data: updated, error: updateError } = await db.from('games').update(patch).eq('id', gameId).select().single();
    if (updateError) throw updateError;
    return NextResponse.json(updated);
  } catch (error) {
    return NextResponse.json({ error: error instanceof Error ? error.message : 'Unknown error' }, { status: 500 });
  }
}
